SAM (Software Automatic Mouth) - I Have A Mouth And I Can Scream

The 1982 Commodore 64 speech synthesizer, as an NVDA voice and a
desktop app. Both are in this archive, and both are self-contained:
there is no Python or other runtime to install first.


THE NVDA ADDON  --  sam.nvda-addon

    1. Double-click sam.nvda-addon with NVDA running
    2. Accept the prompt, then restart NVDA
    3. NVDA menu -> Preferences -> Settings -> Speech
    4. Choose "SAM (Software Automatic Mouth)"

Rate, pitch, inflection and volume behave as usual. Mouth, Throat and
Sing mode are added to the settings ring. Needs NVDA 2023.1 or newer.


THE DESKTOP APP  --  sam_gui-x64.exe, sam_gui-x86.exe

Run the one that matches your Windows: x64 on a 64-bit system, x86 on
a 32-bit one. Nothing to install, and it writes no settings outside
its own window - copy it wherever you like.

Type text, set Speed, Pitch, Mouth, Throat and Inflection, pick a
voice preset, then Preview or save a WAV. Phoneme mode takes SAM's own
phoneme spelling instead of English, and Sing mode holds each vowel on
its pitch.


LICENCE

SAM is reverse-engineered software whose copyright is held by
SoftVoice, Inc.; it is not, and cannot be, under an open source
licence. The bundled CMU Pronouncing Dictionary is licensed separately
by Carnegie Mellon University. LICENSE and NOTICE.md in this archive
have the full position and the per-component attributions.


SOURCE

https://github.com/dengopaiv/ihamaics
